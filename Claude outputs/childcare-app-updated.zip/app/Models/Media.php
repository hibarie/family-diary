<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Storage;

class Media extends Model
{
    protected $fillable = ['disk', 'path', 'type'];

    protected $appends = ['url'];

    public function mediable()
    {
        return $this->morphTo();
    }

    /**
     * フロントエンドがそのまま<img>/<video>のsrcに使える公開URL。
     */
    public function getUrlAttribute(): string
    {
        return Storage::disk($this->disk)->url($this->path);
    }
}
